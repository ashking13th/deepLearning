## CS671 Assignment 3
### Iris Image Segmentation

Run  `q2.py` after modifying the test and train data paths.
Predicted Output masks will get saved in results.npy file