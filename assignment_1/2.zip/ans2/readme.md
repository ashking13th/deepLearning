dependencies = `tensorflow, numpy`

Both files are jupyter notebook files
ans2Numpy - code using numpy/python (Time taken to run = 1.19s)
ans2Tensor - code using Tensorflow (Time taken to run = 502.11s)

finalPos.npy = Final position of particles after threshold is achieved
finalVel.npy = Final position of velocities after threshold is achieved
