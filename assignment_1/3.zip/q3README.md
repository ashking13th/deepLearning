# Question 3

## Dependencies
Matplotlib 
Jupyter Notebook
Tensorflow

## How to Run
run `ans3a.ipynb` and `ans3c1.ipynb` from jupyter notebook
