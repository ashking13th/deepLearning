# Assignment 2

## Team No 13

Aman Khandelwal     B16007

Amrendra Singh      B16010

Bharat Lodhi        B16015

## 1.zip
Solutions to question 1

## 2.zip 
Solutions to question 2

## 3.zip 
Solutions to question 3

All the folders contain a file `readme.md` which contains specific instructions to run the codes in that file