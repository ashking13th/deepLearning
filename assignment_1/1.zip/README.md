Dependency:- `opencv`,`numpy`

for images:-
Run  program.py for creating images as `python3 program.py`

for video first run the above commands and then:-
Run  makevideo.py for creating images as `python3 makevideo.py`


