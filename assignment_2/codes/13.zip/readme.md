1. 1.zip => Question 1
2. 2.zip => Question 2
3. 3.zip => Question 3

All the folders contain individual readme.md with instructions on how to use the codes.
