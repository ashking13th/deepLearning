1. q1.ipynb
2. q1_lineSet.ipynb

Open the files in Jupyter Notebook